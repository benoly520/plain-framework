// 由 plain 编译器自动生成：不要手工编辑。
// 这些函数只在服务端执行；客户端 bundle 里只有 rpc(name, args) 调用桩。

export const fetchStats = async () => {
  return { users: 1024, online: 37, version: "0.3.0" };
};
export const checkKeyword = async (word) => {
  const banned = ["\u6D4B\u8BD5", "todo", "aaa"];
  return { ok: !banned.includes(String(word || "").trim().toLowerCase()) };
};

export const __plainHandlers = {
  fetchStats,
  checkKeyword,
};

export async function handle(name, args = []) {
  const fn = __plainHandlers[name];
  if (!fn) throw new Error('unknown server fn: ' + name);
  return await fn(...args);
}
